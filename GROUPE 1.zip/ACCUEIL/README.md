# Chess Game

## Description
Ce projet est une implémentation d'un jeu d'échecs en HTML/CSS/JS. Il permet à deux joueurs de s'affronter sur un plateau d'échecs virtuel avec toutes les règles classiques du jeu d'échecs.

## Fonctionnalités
- Interface graphique pour jouer aux échecs
- Gestion complète des règles du jeu d'échecs
- Possibilité de mettre en pause le jeu
- Indicateur de tour (blancs/noirs)
- Chronometre
